library()

chooseCRANmirror()

install.packages("e1071")

update.packages("e1071")

library(e1071)

help(package ="e1071")

help(svm, e1071)

?e1071::svm

help.search("svm")

??svm

args(lm)

example(lm)

demo(graphics)

demo()


#Reading and writing data

getwd()
data()
data("iris")
class(iris)
save(iris, file="myData.RData")
load("myData.RData")
test.data = read.table(header = TRUE, text = "
                       a b
                       1 2
                       3 4
                       ")
test.data = read.table(text = "
                       1 2
                       3 4",
                       col.names=c("a","b"),
                       row.names = c("first","second"))

class(test.data)

write.table(test.data, file = "test.txt" , sep = " ")

write.csv(test.data, file = "test.csv")

csv.data = read.csv("test.csv", header = TRUE, row.names=1)

head(csv.data)

?url

install.packages("xlsx")

library("xlsx")

write.xlsx(iris, file = "iris.xls")


#Using R to manipulate data

data(iris)
iris[1,"Sepal.Length"]
Sepal.iris = iris[, c("Sepal.Length", "Sepal.Width")]
str(Sepal.iris)
Five.Sepal.iris = iris[1:5, c("Sepal.Length", "Sepal.Width")]
str(Five.Sepal.iris)
setosa.data = iris[iris$Species=="setosa",1:5]
str(setosa.data)
which(iris$Species=="setosa")
setosa.data = iris[which(iris$Species=="setosa"),1:5]
str(setosa.data)
Sepal.data = subset(iris, select=c("Sepal.Length", "Sepal.Width"))
str(Sepal.data)
setosa.data = subset(iris, Species =="setosa")
str(setosa.data)
example.data= subset(iris, Petal.Length <=1.4 & Petal.Width >=0.2, select=Species )
str(example.data)
flower.type = data.frame(Species = "setosa", Flower = "iris")
merge(flower.type, iris[1:3,], by ="Species")
head(iris[order(iris$Sepal.Length, decreasing = TRUE),])
sub("e", "q", names(iris))
gsub("e", "q", names(iris))


#Applying basic statistics

data(iris)
class(iris)
mean(iris$Sepal.Length)
sd(iris$Sepal.Length)
var(iris$Sepal.Length)
min(iris$Sepal.Length)
max(iris$Sepal.Length)
median(iris$Sepal.Length)
range(iris$Sepal.Length)
quantile(iris$Sepal.Length)

sapply(iris[1:4], mean, na.rm=TRUE)

summary(iris)

cor(iris[,1:4])
cov(iris[,1:4])

t.test(iris$Petal.Width[iris$Species=="setosa"],
       iris$Petal.Width[iris$Species=="versicolor"])

cor.test(iris$Sepal.Length, iris$Sepal.Width)

aggregate(x=iris[,1:4],by=list(iris$Species),FUN=mean)

library(reshape)
iris.melt <- melt(iris,id='Species')
cast(Species~variable,data=iris.melt,mean,
     subset=Species %in% c('setosa','versicolor'),
     margins='grand_row')

?reshape
?aggregate

#Visualizing data

data(iris)
table.iris = table(iris$Species)
table.iris
pie(table.iris)
hist(iris$Sepal.Length)
boxplot(Petal.Width ~ Species, data = iris)
plot(x=iris$Petal.Length, y=iris$Petal.Width, col=iris$Species)
pairs(iris[1:4], main = "Edgar Anderson's Iris Data", pch = 21,
      bg = c("red", "green3", "blue")[unclass(iris$Species)])

#Getting a dataset for machine learning

iris.data = read.csv(url("http://archive.ics.uci.edu//ml//machine-learning-databases//iris//iris.data"),
                     header = FALSE,col.names = c("Sepal.Length", "Sepal.Width", "Petal.Length",
                                                  "Petal.Width","Species"))

head(iris.data)


